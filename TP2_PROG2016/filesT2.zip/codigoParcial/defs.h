#pragma once


#define ALTURA_ECRA 24

#define TAB_BIG "          "
#define TAB    "   "

