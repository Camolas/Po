#include "utils.h"


void clearScreen(){
  // A IMPLEMENTAR
}


unsigned short int leUnsignedShortInt(unsigned short int min, unsigned short int  max){

  // A IMPLEMENTAR

}


int leInteiro(int min, int max){

  // A IMPLEMENTAR

}
